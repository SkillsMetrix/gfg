import React from 'react';
import { useSelector } from 'react-redux'
function ProductComponent(props) {


    const data= useSelector(state => state.allProducts)
    console.log(data);
    
    return (
        <div>
            <p>Product Comp</p>
        </div>
    );
}

export default ProductComponent;