



import React from 'react';
import { useSelector } from 'react-redux'
import ProductComponent from './ProductComponent';

function ProductListing(props) {
    const data= useSelector(state => state.allProducts)
     
    return (
        <div className="ui grid container"> 
        <h3>Product Listing</h3>
            <ProductComponent/>
        </div>
    );
}

export default ProductListing;